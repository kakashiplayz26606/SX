# Script to fix the change_status function
with open('shadowx.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Find the change_status function and add a bot readiness check
new_lines = []
i = 0
while i < len(lines):
    line = lines[i]
    
    # Look for the start of the change_status function
    if "@tasks.loop(minutes=5)" in line and "async def change_status():" in lines[i+1]:
        new_lines.append(line)
        i += 1
        new_lines.append(lines[i])  # async def change_status():
        i += 1
        new_lines.append(lines[i])  # """Change bot status every 5 minutes"""
        i += 1
        new_lines.append(lines[i])  # try:
        i += 1
        
        # Add the bot readiness check right after the try block
        new_lines.append("        # Check if bot is ready before trying to change presence\n")
        new_lines.append("        if bot is None or not hasattr(bot, 'user') or bot.user is None:\n")
        new_lines.append("            print(\"Bot not ready yet, skipping status update\")\n")
        new_lines.append("            return\n")
        new_lines.append("            \n")
    else:
        new_lines.append(line)
        i += 1

# Write the fixed content back to the file
with open('shadowx.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("change_status function fixed!")